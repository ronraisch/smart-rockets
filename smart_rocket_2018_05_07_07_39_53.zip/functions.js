//receiving a vector with polar and coordinates
//output is the same vector in cartesian coordinates
function pol2car(f) {
  if (f) {
    let p = createVector(1, 0)
    p.mult(f.x)
    p.rotate(f.y)
    return p
  } else return f
}
//just painting the obsticles, actual creation in mouseReleased
function obsticleStuff() {
  fill(200);
  rectMode(CORNER);
  for (let i = 0; i < obsticles.length; i++) {
    obsticles[i].show();
  }
}
//calculating succes rate of the group
function succesRate() {
  let sum = 0;
  //summing the amount of succesfull rockets
  for (let i = 0; i < population.rockets.length; i++) {
    if (population.rockets[i].hit) {
      sum++;
    }
  }
  return (sum / nRockets) * 100;
}

function deleteObsticle(){
	obsticles.splice(-1,1)
}
//function for the pause/play button
function pause() {
  if (paused) {
    pauseButton.html('pause')
    paused = false
  } else {
    pauseButton.html('play')
    paused = true
  }
}

//resets population but not the obsticles
function startOver() {
  start = false;
  population = new Population();
  generation = 0;
  count = 0;
  bestTime = Infinity;
  succesGen = null
  succes=0
  currentBest=Infinity
}
//resets everything
function reset() {
  start = false;
  population = new Population();
  obsticles = [];
  generation = 0;
  count = 0;
  bestTime = Infinity;
	succesGen = null
  succes=0
  currentBest=Infinity
}

function startEvolve() {
  start = true;
}
function buttons(){
	startButton = createButton('start');
  startButton.position(0,400)
  startButton.mousePressed(startEvolve);
  pauseButton = createButton('pause')
  pauseButton.position(40,400)
  pauseButton.mousePressed(pause)
  startover = createButton('start over');
  startover.position(90,400)
  startover.mousePressed(startOver);
  buttonReset = createButton('reset');
  buttonReset.position(160,400)
  buttonReset.mousePressed(reset);
  deleteButton=createButton('delete')
  deleteButton.position(205,400)
  deleteButton.mousePressed(deleteObsticle)
}
//caclulating distance squared for optimization
function distSq(x1,y1,x2,y2){
	return (x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)
}

// //function that does only calculation for the algorithm
// function skip() {
//   for (let i = 0; i < genSkip; i++) {
//     //check each generation
//     if (succes > 0 && succesGen == null) {
//       succesGen = generation
//     }
//     //everything that should be done each frame
//     for (let j = 0; j < framesPerRun; j++) {
//       //only calculting pos not showing it
//       population.calcGen();
//       population.checkStuff();
//       count++;
//       if (population.death) {
//         //calculating succes if population is dead
//         succes = succesRate();
//         succes = floor(succes * 10) / 10;
//         //raising kids
//         population.crossOver();
//         count = 0;
//         population.death = false;
//         generation++;
//       }
//     }
//     //reseting current best
//     currentBest=Infinity 
//   }
// }

