let population;//our population
const nRockets = 500;//number of rockets
const forceMag = 0.8;//max force that is applied on rockets
const framesPerRun = 250;//number of frames per generation
let count = 0; //amount of frames passed
const mutationRate = 0.003;
let targetx;//x coordinate of the target
const angleRange = 3.141592653 / 4//max angle for turning
const targety = 50;//y coordinate of the target
const targetr = 7.5;//radius of the target
let obsticles = [];//array for obsitcles
let x, y;//tmp for the click of the mouse
let succesGen = null;//first generation to succed
let bestTime = Infinity;
let currentBest=Infinity
let generation = 0;
let startButton;
let start = false;//boolean for starting the simulation
let buttonReset;
let succes = 0;//variable for succes rate
let startover;//button
let highest;//variable for highest obsticle
let Pframe;
let pauseButton;
let paused = false;//boolean for pause
//rateScl-rate wanted by slider
//actualRate-rate times frame rate/frames per run
let rateSlider,rateP,rateScl,actualRate
let deleteButton
function setup() {
  createCanvas(400, 400);
  //buttons(creation, positioning,functions and names)
  buttons()
  //frame rate and actual rate paragraph
  Pframe = createP()
  Pframe.position(0,440)
  //slider and paragraph for rate
  rateSlider=createSlider(1,200,1,1)
  rateSlider.position(0,430)
  rateP=createP()
  rateP.position(140,417)
  //initializing all
  targetx = width / 2;
  highest = height;
  population = new Population();
  background(0);
  fill(255, 150);
  noStroke();
}
//starting to create obsticles
function mousePressed() {
  x = mouseX;
  y = mouseY;
}

function mouseReleased() {
  //adding obsticles
  if (mouseX < width * 1.1 && mouseY < height * 1.1 &&
      mouseX > -50 && mouseY > -50) {
    obsticles.push(new Obsticle(x, y, mouseX, mouseY));
    //updating the value for highest (see : line 22)
    if (y < highest)
      highest = y;
    if (mouseY < highest)
      highest = mouseY;
  }
}

function draw() {
  //graphics and P stuff
  obsticleStuff();
    if (frameCount%3==0)
      Pframe.html("frame rate:"+int(frameRate())+"  "+
        "actual rate:"+int(rateScl*frameRate())/framesPerRun)
  rateP.html("rate:x"+rateScl)
  //updating the valuse to the slider value
  rateScl=rateSlider.value()
  //if for the "pause" button to work
  if (!paused) {
    //elemntry drawing
    background(0);
    obsticleStuff();//(see : functions.js)
    fill(255, 0, 0);//can be used with text for optimization
    ellipse(targetx, targety, targetr*2);//target drawing
    //main operation
    //performing the loop according to rate slider
    for (let i=0;i<rateScl;i++){
      if (start) {
        //final entry to loop-drawing the rockets
        if (i==rateScl-1){
        	population.graphics();
        }
        //otherwise-only calculation of the rockets
        else{
          population.calcGen()
        }
        //checking the population and updating count
        population.checkStuff();
        count++;
        //repopulating and evaluting the genration
        if (population.death) {
          //calculating succes
          succes = succesRate();
          succes = floor(succes * 10) / 10;
          //reseting environment and repopulating
          count = 0;
          population.repopulate()
        }
      }
    }
    //updating succesGen (see : line 13) 
    if (succes > 0 && succesGen == null) {
      succesGen = generation
    }
    //some texts
    //should be changed to P for optimaztion
    fill(255);
    text("current best:"+currentBest,10,height-80)
    text("first generation to succed:" + succesGen, 10, height - 65)
    text("succes rate:" + succes + "%", 10, height - 50);
    text("count:" + count, 10, height - 20);
    text("generation:" + generation, 10, height - 35);
    text("best time:" + bestTime, 10, height - 5);
  }
}

