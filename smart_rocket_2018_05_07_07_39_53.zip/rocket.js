class Rocket{
	constructor(dna){
    //position of the rocket
  	this.pos=createVector(width/2,height);
    //velocity of the rocket
    this.vel=createVector(0,0);
    //acceleration of the rocket
    this.acc=createVector(0,0);
    //dna of the rocket (see: dna.js)
    this.dna=dna;
    //boolean for hitting the target
    this.hit=false;
    //the probability of the rocket
    //to be picked for crossover
    this.prob=0;
    //boolean for crashing
    this.crashed=false;
    //variable for the time the rocket hit
    //his best distance
    this.count=0;
    //best distance of the rocket
    this.distance=(width*width+height*height);
    //best vertical distance of the rocket
    this.Ydist=height
  }
  //checking if the rocket hit any obsticle
  obsticles(){
  	for (let i=0;i<obsticles.length;i++){
    	let x=this.pos.x;
      let y=this.pos.y;
      let x1=obsticles[i].x1;
      let x2=obsticles[i].x2;
      let y1=obsticles[i].y1;
      let y2=obsticles[i].y2;
      let leftx=min([x1,x2]);
      let rightx=max([x1,x2]);
      let ytop=min([y1,y2]);
      let ybottom=max([y1,y2]);
      if (x>leftx && x<rightx && y>ytop && y<ybottom){
      	this.crashed=true;
        break
      }
    }
  }
  //main function for rocket
  update(){
    if (!this.hit && !this.crashed){
      //calculating best distance
      let d=distSq(targetx,targety,this.pos.x,this.pos.y);
      if (d<this.distance){
      	this.distance=d;
      	this.count=count
      }
      //calculating dy
      let dy=abs(targety-this.pos.y)
      if (dy<this.Ydist)
        this.Ydist=dy
      //moving rocket according to his dna
    	this.applyForce(pol2car(this.dna.genes[count]));
  		this.vel.add(this.acc);
    	this.pos.add(this.vel);
    	this.acc.mult(0);
      //checking if crashed
      if (this.pos.x>width || this.pos.x<0 ||
        this.pos.y>height ||this.pos.y<0){
    		this.crashed=true;
    	}
    	this.obsticles();
    }
    //checking if hit
		if (this.distance<=(targetr*targetr) && !this.hit){
    	this.hit=true;
      //updating records and time
      this.distance=targetr*targetr
      bestTime=min(bestTime,count)
      currentBest=min(currentBest,count)
      this.count=count
    }
  }
  //applying a given cartesian force
  applyForce(force){
  	this.acc.add(force);
  }
  //drawing the rocket
  show(){
  	push();
    translate(this.pos.x,this.pos.y)
    rotate(this.vel.heading());
    rect(0,0,50,10);
    pop();
  }
  //fitness function
  calcFitness(){
    let fit =5/this.distance;
    if (this.hit){
      fit+=10/this.count
      fit*=10
    }
    return fit;
  }
}
