class DNA{
	constructor(genes){
    //constructor if genes are given
    if (genes){
    	this.genes=genes;
    }
    //creating random genes
    else{
  		this.genes=[];
    	for (let i=0;i<framesPerRun;i++){
    		let f=createVector(random(-forceMag,forceMag),random(-angleRange,angleRange));
      	this.genes.push(f);
    	}
    }
  }
  crossOver(rocket){//rocket's dna not rocket object
    let newGenes=[];
    //choosing genes from other and this rocket randomly
    for (let i=0;i<this.genes.length;i++){
    	if (0.5<random()){
      	newGenes.push(this.genes[i]);
      }
      else{
      	newGenes.push(rocket.genes[i]);
      }
    }
    return newGenes;
  }
  //changing one gene randomly
  mutate(){
  	for (let i=0;i<this.genes.length;i++){
    	if (mutationRate>random()){
        let f=createVector(random(-forceMag,forceMag),random(-angleRange,angleRange));
      	this.genes[i]=f;
      }
    }
  }
}