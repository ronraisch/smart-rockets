class Population{
	constructor(){
    count=0;
    this.death=false;//boolean for death
  	this.rockets=[];
    //initializing population
    for (let i=0;i<nRockets;i++){
    	this.rockets.push(new Rocket(new DNA()));
    }
  }
  //drawing and updating each rocket
  graphics(){
    fill(255,150);
    rectMode(CENTER);
    for (let i=0; i<this.rockets.length;i++){
    	this.rockets[i].update();
      this.rockets[i].show();
    }
  }
  //only updateing each rocket
  calcGen(){
  	for (let i=0; i<this.rockets.length;i++){
    	this.rockets[i].update();
    }
  }
  //checking for end of the population
  checkStuff(){
  	if (count>framesPerRun){
    	this.death=true;
    }
    else{
      for (let i=0;i<nRockets;i++){
        this.death=true
        if (!this.rockets[i].hit &&
            !this.rockets[i].crashed){
          this.death=false
          break
        }
      }
    }
  }
  //calculating probabilities for each rocket to be chosen
  makeProb(){
    let sum=0;
    //summing the fitness values
  	for (let i=0;i<this.rockets.length;i++){
    	sum+=this.rockets[i].calcFitness();
    }
    //setting probabilities based on the sum
    for (let i=0;i<this.rockets.length;i++){
    	this.rockets[i].prob=this.rockets[i].calcFitness()/sum;
    }
  }
  //choosing a rocket based on his probability
  pickOne(){
  	let r=Math.random();
    let index=0;
    while (r>0){
    	r-=this.rockets[index].prob;
      index++;
    }
    index--;
    return this.rockets[index];
  }
  //performing crossover(and mutation) on the entire population
  crossOver(){
    this.makeProb();//calculate prob
    let newPopulation=[];
  	for (let i=0;i<this.rockets.length;i++){
      //picking 2 parents
    	let parentA=this.pickOne().dna;
      let parentB=this.pickOne().dna;
      //make a child
      let child=parentA.crossOver(parentB);
      let tmp=new DNA(child);
      //mutate the child
      tmp.mutate();
      //adding him to the population
      newPopulation.push(new Rocket(tmp));
      
    }
    this.rockets=newPopulation;
  }
  repopulate(){
  	population.crossOver();
    population.death = false;
    generation++;
    currentBest=Infinity 
  }
}